﻿using System.Windows;

namespace st1009155progp12023.st1009155progp12023
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}