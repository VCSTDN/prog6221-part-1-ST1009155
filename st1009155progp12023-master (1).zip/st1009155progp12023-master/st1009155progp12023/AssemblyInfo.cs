﻿using System.Windows;

// (used if a resource is not found in the page,
// or application resource dictionaries)
// (used if a resource is not found in the page,
// app, or any theme specific resource dictionaries)
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)] // where theme specific resource dictionaries are located
// where the generic resource dictionary is located

