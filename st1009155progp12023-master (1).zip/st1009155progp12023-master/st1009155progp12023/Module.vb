﻿Public Class [Module]
    Public Property Code As String
    Public Property Name As String
    Public Property Credits As Integer
    Public Property ClassHoursPerWeek As Integer
End Class
