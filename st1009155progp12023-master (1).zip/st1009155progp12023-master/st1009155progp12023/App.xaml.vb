﻿Imports System.Windows

Namespace st1009155progp12023
    ''' <summary>
    ''' Interaction logic for App.xaml
    ''' </summary>
    Public Partial Class App
        Inherits Application
    End Class
End Namespace
