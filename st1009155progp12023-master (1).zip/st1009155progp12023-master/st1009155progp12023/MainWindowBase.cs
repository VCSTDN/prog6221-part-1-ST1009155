﻿
namespace st1009155progp12023.st1009155progp12023
{
    public class MainWindowBase
    {
    }
}